﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorrorGame_230621
{
    public class Program
    {
        static void Main(string[] args)
        {
            Enemy enemyCode = new Enemy();
            Map mapCode1 = new Map();
            mapCode1.Print_Map();
            
        }
    }
}
